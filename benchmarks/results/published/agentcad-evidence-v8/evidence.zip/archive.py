"""Freeze the standard-runner submission, preserving its original JSON bytes."""
from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

OUT = Path(__file__).resolve().parent
REPO = Path('D:/Projects/Autocad-MCP-agentcad-submission')
PRODUCT = REPO / 'benchmarks/.competitors/agentcad/repo'
PUBLISHED = REPO / 'benchmarks/results/published'
DEST = PUBLISHED / 'agentcad-evidence-v8'
REPORT = OUT / 'native-run/published.json'
PIN = '39fa4b55899233ab7ac5cbb52714a4767ca164c6'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def read_log(path):
    data = path.read_bytes()
    return data.decode('utf-16' if data.startswith((b'\xff\xfe', b'\xfe\xff')) else 'utf-8-sig')

report = json.loads(REPORT.read_text(encoding='utf-8'))
assert report['summary']['attempted'] == report['summary']['passed'] == 31
assert report['summary']['score'] == 100
assert report['adapter_metadata']['product_sha'] == PIN
assert report['adapter_metadata']['product_dirty'] is False
assert report['manifest']['dirty'] is False
assert report['manifest']['server_sha'] == '8c805f049fd6048a8b99b3d7be1f1e9534ac7cfc'
assert not DEST.exists(), 'Never overwrite an evidence archive'
assert not (PUBLISHED / 'agentcad.json').exists()
log = read_log(OUT / 'pytest-upstream.log')
assert '6071 passed, 1 xfailed' in log
entries = {}
for p in sorted((OUT / 'native-run').rglob('*')):
    if p.is_file():
        entries['run/' + p.relative_to(OUT / 'native-run').as_posix()] = p.read_bytes()
for name in ('native.stdout.json', 'native.stderr.log', 'pytest-upstream.log', 'archive.py'):
    entries[name] = (OUT / name).read_bytes()
for name in ('benchmarks/adapters/agentcad.py', 'benchmarks/competitors.yaml', 'tests/test_benchmark_agentcad.py'):
    entries['submission/' + name] = (REPO / name).read_bytes()
for name in ('run.py', 'cancel_worker.py'):
    entries['playbooks/' + name] = (PRODUCT / 'examples/autocad_benchmark' / name).read_bytes()
paths = subprocess.check_output(['git', '-C', str(PRODUCT), 'ls-files', 'src/agentcad/*.py', 'src/agentcad/**/*.py'], text=True).splitlines()
for name in paths:
    entries['product/' + name] = (PRODUCT / name).read_bytes()
for name, expected in report['adapter_metadata']['source_sha256'].items():
    assert sha(entries['product/' + name]) == expected, name
raw = json.loads(read_log(OUT / 'native.stdout.json'))
artifacts = []
for result in raw['results']:
    for a in result['artifacts']:
        path = Path(a['path'])
        data = path.read_bytes()
        assert sha(data) == a['sha256'], str(path)
        archive_path = 'run/' + path.relative_to(OUT / 'native-run').as_posix()
        assert entries[archive_path] == data
        artifacts.append({'task_id': result['task_id'], 'archive_path': archive_path, 'sha256': a['sha256']})
upstream_files = subprocess.check_output(['git', '-C', str(REPO), 'ls-tree', '-r', '--name-only', '58a05dd', 'benchmarks', 'tests/fixtures', 'engineering'], text=True).splitlines()
oracle_sources = {}
for name in upstream_files:
    if name.endswith('.py'):
        data = (REPO / name).read_bytes()
        original = subprocess.check_output(['git', '-C', str(REPO), 'show', '58a05dd:' + name])
        assert data.replace(b'\r\n', b'\n') == original, name
        oracle_sources[name] = {'sha256': sha(data), 'git_blob_content_sha256': sha(original)}
entries['evaluator-source-hashes.json'] = (json.dumps(oracle_sources, indent=2) + '\n').encode()
DEST.mkdir(parents=True)
archive = DEST / 'evidence.zip'
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, data in sorted(entries.items()):
        z.writestr(name, data)
manifest = {
    'archive': 'evidence.zip', 'sha256': sha(archive.read_bytes()), 'size_bytes': archive.stat().st_size,
    'product_sha': PIN, 'evaluator_sha': report['manifest']['server_sha'],
    'upstream_base': '58a05ddfc34a9832c626e82cd88ecdce8e16a62a',
    'command': 'python -m benchmarks.run_competitors --server agentcad --backend ezdxf --matrix v8 --timeout 180 --no-fetch --artifact-dir <new-directory> --publish <new-report.json> --json',
    'summary': report['summary'], 'v2_passed': 10, 'v2_total': 10,
    'regression': {'passed': 6071, 'xfailed': 1, 'warnings': 166},
    'publication': {'path': '../agentcad.json', 'sha256': sha(REPORT.read_bytes()), 'modified_from_runner_publish': False},
    'original_measurement': {
        'url': 'https://github.com/lizaixi01/AgentCAD/tree/a3b336a4535bc3cc2a2435f4ebdc76b90f70153c/examples/autocad_benchmark/results/2026-10-30-v8/integrated',
        'archive_sha256': '98e9a11bd25c33fb01ed8de90129b0fc2fffa14f032232cc0cd175cb63f7b69b',
        'preserved': True,
    },
    'artifacts': artifacts,
    'entries': [{'path': name, 'size_bytes': len(data), 'sha256': sha(data)} for name, data in sorted(entries.items())],
}
(DEST / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
(PUBLISHED / 'agentcad.json').write_bytes(REPORT.read_bytes())
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist()) == len(manifest['entries'])
    for e in manifest['entries']:
        assert sha(z.read(e['path'])) == e['sha256']
print(json.dumps({'entries':len(entries), 'source_files':len(paths), 'oracle_sources':len(oracle_sources), 'artifacts':len(artifacts), 'zip_sha256':manifest['sha256'], 'zip_bytes':manifest['size_bytes']}))
